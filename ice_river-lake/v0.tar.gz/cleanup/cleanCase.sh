rm -rf ./outputs/*

touch ./outputs/fatal.error