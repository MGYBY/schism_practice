mpirun --oversubscribe -np 12 ./pschism_MICE_PREC_EVAP_BLD_STANDALONE_SH_MEM_COMM_TVD-VL 11
