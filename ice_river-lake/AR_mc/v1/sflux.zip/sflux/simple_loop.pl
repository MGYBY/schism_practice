#! /usr/bin/perl -w

# Simple loop to process a series of files. Modify as approp.

for($i=1;$i<=9; $i++)
{
  $j=sprintf('%1d',$i);
  $file="sflux_air_1."."$j".".nc";
  $file2="sflux_rad_1."."$j".".nc";
  $file3="sflux_prc_1."."$j".".nc";
  print "doing $file\n";
  system "ln -sf $file $file2";
  system "ln -sf $file $file3";
}
